import { Component } from '@angular/core';

@Component({
  selector: 'app-assign-admin-dialogue',
  templateUrl: './assign-admin-dialogue.component.html',
  styleUrls: ['./assign-admin-dialogue.component.css']
})
export class AssignAdminDialogueComponent {

}
