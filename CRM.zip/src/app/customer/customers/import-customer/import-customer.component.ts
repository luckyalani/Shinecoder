import { Component } from '@angular/core';

@Component({
  selector: 'app-import-customer',
  templateUrl: './import-customer.component.html',
  styleUrls: ['./import-customer.component.css']
})
export class ImportCustomerComponent {

}
