import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-zip-invoices',
  templateUrl: './zip-invoices.component.html',
  styleUrls: ['./zip-invoices.component.css']
})
export class ZipInvoicesComponent {
  
}
