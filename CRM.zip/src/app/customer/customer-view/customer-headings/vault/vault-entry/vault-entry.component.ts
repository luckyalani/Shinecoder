import { Component } from '@angular/core';

@Component({
  selector: 'app-vault-entry',
  templateUrl: './vault-entry.component.html',
  styleUrls: ['./vault-entry.component.css']
})
export class VaultEntryComponent {

}
