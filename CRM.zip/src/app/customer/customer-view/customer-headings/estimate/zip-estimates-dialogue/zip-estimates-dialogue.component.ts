import { Component } from '@angular/core';

@Component({
  selector: 'app-zip-estimates-dialogue',
  templateUrl: './zip-estimates-dialogue.component.html',
  styleUrls: ['./zip-estimates-dialogue.component.css']
})
export class ZipEstimatesDialogueComponent {

}
