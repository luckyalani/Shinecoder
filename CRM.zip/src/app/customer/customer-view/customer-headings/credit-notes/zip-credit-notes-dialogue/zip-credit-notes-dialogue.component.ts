import { Component } from '@angular/core';
import { ZipPaymentDialogueComponent } from '../../payment/zip-payment-dialogue/zip-payment-dialogue.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-zip-credit-notes-dialogue',
  templateUrl: './zip-credit-notes-dialogue.component.html',
  styleUrls: ['./zip-credit-notes-dialogue.component.css']
})
export class ZipCreditNotesDialogueComponent {
  
}
