import { Component } from '@angular/core';

@Component({
  selector: 'app-zip-payment-dialogue',
  templateUrl: './zip-payment-dialogue.component.html',
  styleUrls: ['./zip-payment-dialogue.component.css']
})
export class ZipPaymentDialogueComponent {

}
