import { Component } from '@angular/core';

@Component({
  selector: 'app-record-expenses',
  templateUrl: './record-expenses.component.html',
  styleUrls: ['./record-expenses.component.css']
})
export class RecordExpensesComponent {

}
