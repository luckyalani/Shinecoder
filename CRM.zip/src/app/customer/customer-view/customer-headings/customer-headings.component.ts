import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-headings',
  templateUrl: './customer-headings.component.html',
  styleUrls: ['./customer-headings.component.css']
})
export class CustomerHeadingsComponent {

}
