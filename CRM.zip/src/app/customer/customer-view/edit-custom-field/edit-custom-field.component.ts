import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-custom-field',
  templateUrl: './edit-custom-field.component.html',
  styleUrls: ['./edit-custom-field.component.css']
})
export class EditCustomFieldComponent {

}
