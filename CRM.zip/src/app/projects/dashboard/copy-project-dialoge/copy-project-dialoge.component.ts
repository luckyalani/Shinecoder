import { Component } from '@angular/core';

@Component({
  selector: 'app-copy-project-dialoge',
  templateUrl: './copy-project-dialoge.component.html',
  styleUrls: ['./copy-project-dialoge.component.css']
})
export class CopyProjectDialogeComponent {

}
