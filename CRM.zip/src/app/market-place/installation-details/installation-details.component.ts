import { Component } from '@angular/core';

@Component({
  selector: 'app-installation-details',
  templateUrl: './installation-details.component.html',
  styleUrls: ['./installation-details.component.css']
})
export class InstallationDetailsComponent {

}
