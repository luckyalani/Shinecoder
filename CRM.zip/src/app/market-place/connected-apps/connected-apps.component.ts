import { Component } from '@angular/core';

@Component({
  selector: 'app-connected-apps',
  templateUrl: './connected-apps.component.html',
  styleUrls: ['./connected-apps.component.css']
})
export class ConnectedAppsComponent {

}
