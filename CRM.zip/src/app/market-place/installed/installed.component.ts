import { Component } from '@angular/core';

@Component({
  selector: 'app-installed',
  templateUrl: './installed.component.html',
  styleUrls: ['./installed.component.css']
})
export class InstalledComponent {

}
