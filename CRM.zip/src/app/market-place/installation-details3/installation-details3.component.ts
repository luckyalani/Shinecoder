import { Component } from '@angular/core';

@Component({
  selector: 'app-installation-details3',
  templateUrl: './installation-details3.component.html',
  styleUrls: ['./installation-details3.component.css']
})
export class InstallationDetails3Component {

}
