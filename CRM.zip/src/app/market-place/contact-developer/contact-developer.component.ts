import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-developer',
  templateUrl: './contact-developer.component.html',
  styleUrls: ['./contact-developer.component.css']
})
export class ContactDeveloperComponent {

}
