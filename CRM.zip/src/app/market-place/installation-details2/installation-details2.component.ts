import { Component } from '@angular/core';

@Component({
  selector: 'app-installation-details2',
  templateUrl: './installation-details2.component.html',
  styleUrls: ['./installation-details2.component.css']
})
export class InstallationDetails2Component {

}
