import { Component } from '@angular/core';

@Component({
  selector: 'app-renew-contract',
  templateUrl: './renew-contract.component.html',
  styleUrls: ['./renew-contract.component.css']
})
export class RenewContractComponent {

}
