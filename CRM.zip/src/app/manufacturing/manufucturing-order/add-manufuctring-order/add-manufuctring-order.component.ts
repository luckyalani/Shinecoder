import { Component } from '@angular/core';

@Component({
  selector: 'app-add-manufuctring-order',
  templateUrl: './add-manufuctring-order.component.html',
  styleUrls: ['./add-manufuctring-order.component.css']
})
export class AddManufuctringOrderComponent {

}
