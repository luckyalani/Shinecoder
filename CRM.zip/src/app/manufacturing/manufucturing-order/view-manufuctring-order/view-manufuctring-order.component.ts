import { Component } from '@angular/core';

@Component({
  selector: 'app-view-manufuctring-order',
  templateUrl: './view-manufuctring-order.component.html',
  styleUrls: ['./view-manufuctring-order.component.css']
})
export class ViewManufuctringOrderComponent {

}
