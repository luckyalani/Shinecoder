import { Component } from '@angular/core';

@Component({
  selector: 'app-view-work-order',
  templateUrl: './view-work-order.component.html',
  styleUrls: ['./view-work-order.component.css']
})
export class ViewWorkOrderComponent {

}
