import { Component } from '@angular/core';

@Component({
  selector: 'app-add-bill-material',
  templateUrl: './add-bill-material.component.html',
  styleUrls: ['./add-bill-material.component.css']
})
export class AddBillMaterialComponent {

}
