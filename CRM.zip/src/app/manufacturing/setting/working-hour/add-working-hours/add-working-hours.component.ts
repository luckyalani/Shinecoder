import { Component } from '@angular/core';

@Component({
  selector: 'app-add-working-hours',
  templateUrl: './add-working-hours.component.html',
  styleUrls: ['./add-working-hours.component.css']
})
export class AddWorkingHoursComponent {

}
