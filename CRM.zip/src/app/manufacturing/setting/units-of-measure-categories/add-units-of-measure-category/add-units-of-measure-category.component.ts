import { Component } from '@angular/core';

@Component({
  selector: 'app-add-units-of-measure-category',
  templateUrl: './add-units-of-measure-category.component.html',
  styleUrls: ['./add-units-of-measure-category.component.css']
})
export class AddUnitsOfMeasureCategoryComponent {

}
