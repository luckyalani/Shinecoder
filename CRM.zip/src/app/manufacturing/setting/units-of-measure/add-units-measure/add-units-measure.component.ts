import { Component } from '@angular/core';

@Component({
  selector: 'app-add-units-measure',
  templateUrl: './add-units-measure.component.html',
  styleUrls: ['./add-units-measure.component.css']
})
export class AddUnitsMeasureComponent {

}
