import { Component } from '@angular/core';

@Component({
  selector: 'app-work-center-view',
  templateUrl: './work-center-view.component.html',
  styleUrls: ['./work-center-view.component.css']
})
export class WorkCenterViewComponent {

}
