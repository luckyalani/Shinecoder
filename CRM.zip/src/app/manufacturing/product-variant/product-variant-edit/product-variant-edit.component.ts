import { Component } from '@angular/core';

@Component({
  selector: 'app-product-variant-edit',
  templateUrl: './product-variant-edit.component.html',
  styleUrls: ['./product-variant-edit.component.css']
})
export class ProductVariantEditComponent {

}
