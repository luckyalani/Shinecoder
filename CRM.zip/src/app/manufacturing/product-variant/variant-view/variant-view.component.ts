import { Component } from '@angular/core';

@Component({
  selector: 'app-variant-view',
  templateUrl: './variant-view.component.html',
  styleUrls: ['./variant-view.component.css']
})
export class VariantViewComponent {

}
