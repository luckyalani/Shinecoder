import { Component } from '@angular/core';

@Component({
  selector: 'app-click-view-page',
  templateUrl: './click-view-page.component.html',
  styleUrls: ['./click-view-page.component.css']
})
export class ClickViewPageComponent {

}
