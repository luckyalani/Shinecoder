import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-click-gb-editbtnpopup',
  templateUrl: './blog-click-gb-editbtnpopup.component.html',
  styleUrls: ['./blog-click-gb-editbtnpopup.component.css']
})
export class BlogClickGbEditbtnpopupComponent {

}
