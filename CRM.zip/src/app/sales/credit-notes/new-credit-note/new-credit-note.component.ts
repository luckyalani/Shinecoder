import { Component } from '@angular/core';

@Component({
  selector: 'app-new-credit-note',
  templateUrl: './new-credit-note.component.html',
  styleUrls: ['./new-credit-note.component.css']
})
export class NewCreditNoteComponent {

}
