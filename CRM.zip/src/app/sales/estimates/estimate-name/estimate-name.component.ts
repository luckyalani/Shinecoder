import { Component } from '@angular/core';

@Component({
  selector: 'app-estimate-name',
  templateUrl: './estimate-name.component.html',
  styleUrls: ['./estimate-name.component.css']
})
export class EstimateNameComponent {

}
