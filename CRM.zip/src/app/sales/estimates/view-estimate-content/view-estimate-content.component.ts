import { Component } from '@angular/core';

@Component({
  selector: 'app-view-estimate-content',
  templateUrl: './view-estimate-content.component.html',
  styleUrls: ['./view-estimate-content.component.css']
})
export class ViewEstimateContentComponent {

}
