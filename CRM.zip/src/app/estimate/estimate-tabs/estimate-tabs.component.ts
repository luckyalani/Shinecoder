import { Component } from '@angular/core';

@Component({
  selector: 'app-estimate-tabs',
  templateUrl: './estimate-tabs.component.html',
  styleUrls: ['./estimate-tabs.component.css']
})
export class EstimateTabsComponent {

}
